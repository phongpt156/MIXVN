<div class="modal fade" id="alert-login-modal">
    <div class="modal-dialog" role="document" id="">
        <div class="alert-login">
            <div class="alert-login-background">
            
            </div>
            <div class="alert-login-logo">
                <a href="" title=""><img src="http://i.imgur.com/qwR1IG9.png" alt=""></a>
            </div>
            <p>Đăng nhập ngay để được cập nhật những item mới nhất theo sở thích của bạn nhé</p>
            <div class="alert-login-footer row">
                <div class="alert-register col-xs-6">
                    <a href="" title="">Đăng ký</a>
                </div>
                <div class="alert-register col-xs-6">
                    <a href="" title="">Đăng nhập</a>
                </div>
            </div>
        </div>
    </div>
</div>