<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CateGenderXref extends Model
{
    //
    protected $table = 'cate_gender_xref';
}
