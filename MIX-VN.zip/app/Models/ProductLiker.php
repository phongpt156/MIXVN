<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProductLiker extends Model
{
    //
    protected $table = 'product_liker';
}
