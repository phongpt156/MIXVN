<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FeatureDefaultValue extends Model
{
    //
    protected $table = 'feature_default_value';
}
