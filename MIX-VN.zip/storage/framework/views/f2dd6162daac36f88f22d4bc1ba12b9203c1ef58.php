<?php echo Form::open(['route' => 'search-product', 'class' => 'search-form', 'method' => 'get']); ?>

	<div class="search-tagging">
		<div class="list-tagging-container">
				
		</div>
		<div class="input-search-container">
			<?php echo Form::text(
					'product_name',
					'',
					[
						'placeholder' => 'Nhập hoặc chọn "Từ Khóa" bên dưới để tìm sản phẩm'
					]
				); ?>

			<?php echo Form::submit(
					'',
					[
						'class' => 'search-icon'
					]
				); ?>

		</div>
	</div>
<?php echo Form::close(); ?>

