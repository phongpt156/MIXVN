<?php if(isset($products)): ?>
	<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<li class="product-item">
		<div class="product-card">
			<div class="product-image-container" product-id="<?php echo e($value->p_id); ?>">
				<div class="product-image">
					<img src="<?php echo e($value->p_i_name); ?>" alt="">
				</div>
				<div class="user-product-action">
					<ul class="row">
						<?php if(isset($list_product_user_like)): ?>
							<?php if(in_array($value->p_id, $list_product_user_like)): ?>
								<li class="col-xs-4 action-status" action="like-product" product-id="<?php echo e($value->p_id); ?>"><a href="javascript:void(0)" title=""><img src="http://i.imgur.com/LjwCZFM.png" alt=""></a></li>
							<?php else: ?>
								<li class="col-xs-4" action="like-product" product-id="<?php echo e($value->p_id); ?>"><a href="javascript:void(0)" title=""><img src="http://i.imgur.com/LjwCZFM.png" alt=""></a></li>
							<?php endif; ?>
						<?php else: ?>
							<li class="col-xs-4" action="like-product" product-id="<?php echo e($value->p_id); ?>"><a href="javascript:void(0)" title=""><img src="http://i.imgur.com/LjwCZFM.png" alt=""></a></li>
						<?php endif; ?>
						<li class="col-xs-4" product-id="<?php echo e($value->p_id); ?>"><a href="javascript:void(0)" title="" data-toggle="tooltip"><img src="http://i.imgur.com/O7whI4a.png" alt=""></a></li>
						<li class="col-xs-4" title="" product-id="<?php echo e($value->p_id); ?>"><a href="javascript:void(0)" title=""><img src="https://s10.postimg.org/eaem2xss9/ghim.png" alt=""></a></li>
					</ul>
				</div>
			</div>
			<div class="product-info clearfix">
				<div class="product-name">
					<a href="" title=""><?php echo e($value->p_name); ?></a>
				</div>
				<div class="supplier-name">
					<a href="" title=""><?php echo e($value->s_name); ?></a>
				</div>
				<div class="product-info-footer clearfix">
					<div class="product-price">
						<a href="" title=""><?php echo e($value->p_price); ?></a>
					</div>
					<div class="product-sum-like">
						<div product-id="<?php echo e($value->p_id); ?>"><?php echo e($value->p_like); ?></div>
						<span class="fa fa-heart"></span>
					</div>
				</div>
			</div>
		</div>
	</li>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<div class="product-current-page">
		<?php echo e($products->currentPage()); ?>

	</div>
	<div class="product-last-page">
		<?php echo e($products->lastPage()); ?>

	</div>
	<div class="product-next-page-url">
		<?php echo e($products->nextPageUrl()); ?>

	</div>
<?php endif; ?>
