<div class="modal-dialog" role="document">
    <div class="register-form-container">
        <div class="facebook-login-container">
            <a href="<?php echo e(url('user/auth/facebook')); ?>" title=""><img src="http://i.imgur.com/0MmgqMq.jpg" alt=""></a>
        </div>
        <a href="javascript:void(0)" title="" class="phone-register"><p>Đăng ký bằng số điện thoại</p></a>
        <a href="<?php echo e(url('/google/redirect')); ?>" title="" class="gmail-register"><p>Đăng ký bằng gmail</p></a>
        <div class="phone-number-register-box" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        	<?php echo Form::open(['route' => 'add-user-by-phonenumber', 'method' => 'POST', 'class' => 'phone-number-register-form']); ?>

                <?php echo Form::text(
        				'username',
        				'',
        				[
        					'id' => 'phonenumber_register',
        					'name' => 'phonenumber_register',
        					'placeholder' => 'nhập số điện thoại'
        				]
        			); ?>

        		<?php echo Form::password(
        				'username',
        				[
        					'id' => 'password_register',
        					'name' => 'password_register',
        					'placeholder' => 'mật khẩu'
        				]
        			); ?>

        		<?php echo Form::password(
        				'username',
        				[
        					'id' => 'repeatpassword_register',
        					'name' => 'repeatpassword_register',
        					'placeholder' => 'nhập lại mật khẩu'
        				]
        			); ?>

        		<?php echo Form::submit(
	        			'Đăng ký',
	        			[
	        				
	        			]
        			); ?>

        		<button type="button" class="cancel-button" data-dismiss="modal">Hủy</button>
        		<button type="reset" class="cancel-button">Nhập lại</button>
        	<?php echo Form::close(); ?>

        </div>
    </div>
</div>