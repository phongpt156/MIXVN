<?php if(isset($collections)): ?>
	<?php $__currentLoopData = $collections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<li class="collection-item"><a href="" title=""><img src="<?php echo e($value->col_i_name); ?>" alt=""></a></li>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>