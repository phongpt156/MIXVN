<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>MIX VN <?php echo $__env->yieldContent('title'); ?></title>
	<link rel="stylesheet" href="<?php echo asset('plugins/bootstrap/css/bootstrap.min.css'); ?>">
	<script type="text/javascript" src="<?php echo asset('plugins/jquery/jquery.min.js'); ?>"></script>
	<script type="text/javascript" src="<?php echo asset('plugins/bootstrap/js/bootstrap.min.js'); ?>"></script>
	<?php echo $__env->yieldContent('assets'); ?>
	<style type="text/css" media="screen">
		@font-face {
		    font-family: VL_Piron;
		    src: url('<?php echo asset("plugins/home/fonts/VL_Piron.ttf"); ?>');
		}
		@font-face {
		    font-family: VNF-Stag-Sans-Book;
		    src: url('<?php echo asset("plugins/home/fonts/VNF-Stag Sans-Book.ttf"); ?>');
		}
		@font-face {
		    font-family: Saigonese;
		    src: url('<?php echo asset("plugins/home/fonts/Saigonese.otf"); ?>');
		}
	</style>
</head>
<body>
	<?php if(!Auth::check()): ?>
		<?php echo $__env->make('layouts.alert-login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php endif; ?>
	<div class="container-fluid mix-container">
    	<?php echo $__env->yieldContent('content'); ?>
	</div>
</body>
</html>
