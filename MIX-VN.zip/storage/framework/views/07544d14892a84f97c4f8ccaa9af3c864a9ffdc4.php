<?php if(isset($color_default_values)): ?>
<ul class="dropdown-menu list-color-item">
    <?php $__currentLoopData = $color_default_values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    	<li class="color-item"><a href="" title="" style="background-color:<?php echo e(isset($value->other_value) ? $value->other_value : $value->vn_value); ?>" class="search-element" value="<?php echo e(isset($value->vn_value) ? $value->vn_value : $value->other_value); ?>"></a></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php endif; ?>
