<?php if(isset($feature_default_values)): ?>
<ul class="dropdown-menu list-feature-item">
	<?php $__currentLoopData = $feature_default_values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<li class="feature-item"><a href="" title="" class="search-element" value="<?php echo e(isset($value->vn_value) ? $value->vn_value : $value->other_value); ?>"><?php echo e(isset($value->vn_value) ? $value->vn_value : $value->other_value); ?></a></li>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php endif; ?>
